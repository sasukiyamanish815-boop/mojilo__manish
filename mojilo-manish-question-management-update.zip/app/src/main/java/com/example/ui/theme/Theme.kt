package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = PurpleOnPrimary,
    primaryContainer = PurpleHeaderDark,
    onPrimaryContainer = TextOnDarkPrimary,
    secondary = BlueSecondary,
    onSecondary = DarkBackground,
    tertiary = EmeraldSuccess,
    onTertiary = EmeraldOnContainer,
    background = DarkBackground,
    onBackground = TextOnDarkPrimary,
    surface = DarkSurface,
    onSurface = TextOnDarkPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextOnDarkSecondary,
    outline = DarkOutline,
    error = RoseError,
    errorContainer = RoseContainer
)

private val LightColorScheme = DarkColorScheme // Elegant Dark applied globally


@Composable
fun MojiloManishTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
