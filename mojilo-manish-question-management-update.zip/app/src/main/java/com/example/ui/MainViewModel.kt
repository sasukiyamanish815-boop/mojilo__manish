package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.remote.SupabaseConfig
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object Login : Screen()
    object Welcome : Screen()
    object StudentDashboard : Screen()
    data class TakeTest(val test: TestItem) : Screen()
    object AdminDashboard : Screen()
}

data class UiState(
    val currentScreen: Screen = Screen.Splash,
    val currentUser: UserProfile? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,

    // Student state
    val studentTests: List<TestWithStatus> = emptyList(),
    val currentTakingTest: TestItem? = null,
    val testQuestions: List<QuestionItem> = emptyList(),
    val selectedAnswers: Map<String, Int> = emptyMap(), // questionId -> chosenIndex
    val currentQuestionIndex: Int = 0,
    val activeScoreResult: TestScoreResult? = null,

    // Admin state
    val adminStudents: List<UserProfile> = emptyList(),
    val adminTests: List<TestItem> = emptyList(),
    val adminSelectedTestForQuestions: TestItem? = null,
    val adminQuestionsForTest: List<QuestionItem> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        checkExistingSession()
    }

    private fun checkExistingSession() {
        viewModelScope.launch {
            val savedUser = repository.getSavedUserSession()
            if (savedUser != null) {
                _uiState.value = _uiState.value.copy(currentUser = savedUser)
                if (savedUser.role == "admin") {
                    loadAdminData()
                    _uiState.value = _uiState.value.copy(currentScreen = Screen.AdminDashboard)
                } else {
                    loadStudentData(savedUser.id)
                    _uiState.value = _uiState.value.copy(currentScreen = Screen.StudentDashboard)
                }
            } else {
                _uiState.value = _uiState.value.copy(currentScreen = Screen.Splash)
            }
        }
    }

    fun onSplashFinished() {
        val current = _uiState.value
        if (current.currentScreen == Screen.Splash) {
            if (current.currentUser != null) {
                _uiState.value = current.copy(currentScreen = Screen.Welcome)
            } else {
                _uiState.value = current.copy(currentScreen = Screen.Login)
            }
        }
    }

    fun onWelcomeFinished() {
        val current = _uiState.value
        if (current.currentScreen == Screen.Welcome && current.currentUser != null) {
            if (current.currentUser.role == "admin") {
                _uiState.value = current.copy(currentScreen = Screen.AdminDashboard)
            } else {
                _uiState.value = current.copy(currentScreen = Screen.StudentDashboard)
            }
        }
    }

    fun login(mobile: String, pass: String) {
        if (mobile.isBlank() || pass.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "કૃપા કરીને મોબાઈલ નંબર અને પાસવર્ડ દાખલ કરો.")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            val result = repository.login(mobile.trim(), pass.trim())
            _uiState.value = _uiState.value.copy(isLoading = false)

            result.onSuccess { user ->
                _uiState.value = _uiState.value.copy(currentUser = user, errorMessage = null)
                if (user.role == "admin") {
                    loadAdminData()
                    _uiState.value = _uiState.value.copy(currentScreen = Screen.Welcome)
                } else {
                    loadStudentData(user.id)
                    _uiState.value = _uiState.value.copy(currentScreen = Screen.Welcome)
                }
            }.onFailure { exception ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = exception.message ?: "Login નિષ્ફળ રહ્યું."
                )
            }
        }
    }

    fun logout() {
        val user = _uiState.value.currentUser
        viewModelScope.launch {
            if (user != null) {
                repository.logout(user)
            }
            _uiState.value = UiState(currentScreen = Screen.Login)
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    // STUDENT ACTIONS
    fun loadStudentData(studentId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val res = repository.getStudentTests(studentId)
            _uiState.value = _uiState.value.copy(isLoading = false)
            res.onSuccess { tests ->
                _uiState.value = _uiState.value.copy(studentTests = tests)
            }
        }
    }

    fun startTest(test: TestItem) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val res = repository.getQuestionsForTest(test.id)
            _uiState.value = _uiState.value.copy(isLoading = false)

            res.onSuccess { questions ->
                if (questions.isEmpty()) {
                    _uiState.value = _uiState.value.copy(errorMessage = "આ પરીક્ષામાં હજુ સુધી પ્રશ્નો ઉમેરવામાં આવ્યા નથી.")
                } else {
                    _uiState.value = _uiState.value.copy(
                        currentTakingTest = test,
                        testQuestions = questions,
                        selectedAnswers = emptyMap(),
                        currentQuestionIndex = 0,
                        currentScreen = Screen.TakeTest(test)
                    )
                }
            }
        }
    }

    fun selectOption(questionId: String, optionIndex: Int) {
        val currentMap = _uiState.value.selectedAnswers.toMutableMap()
        currentMap[questionId] = optionIndex
        _uiState.value = _uiState.value.copy(selectedAnswers = currentMap)
    }

    fun goToQuestion(index: Int) {
        if (index in 0 until _uiState.value.testQuestions.size) {
            _uiState.value = _uiState.value.copy(currentQuestionIndex = index)
        }
    }

    fun submitTest() {
        val state = _uiState.value
        val student = state.currentUser ?: return
        val test = state.currentTakingTest ?: return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val res = repository.submitTest(
                studentId = student.id,
                testId = test.id,
                questions = state.testQuestions,
                selectedAnswers = state.selectedAnswers
            )
            _uiState.value = _uiState.value.copy(isLoading = false)

            res.onSuccess { scoreResult ->
                _uiState.value = _uiState.value.copy(
                    activeScoreResult = scoreResult
                )
                // Refresh student tests to reflect updated Completed status
                loadStudentData(student.id)
            }
        }
    }

    fun dismissScoreResultDialog() {
        _uiState.value = _uiState.value.copy(
            activeScoreResult = null,
            currentTakingTest = null,
            testQuestions = emptyList(),
            selectedAnswers = emptyMap(),
            currentScreen = Screen.StudentDashboard
        )
    }

    // ADMIN ACTIONS
    fun loadAdminData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val studentsRes = repository.adminGetStudents()
            val testsRes = repository.adminGetTests()
            _uiState.value = _uiState.value.copy(isLoading = false)

            studentsRes.onSuccess { list -> _uiState.value = _uiState.value.copy(adminStudents = list) }
            testsRes.onSuccess { list -> _uiState.value = _uiState.value.copy(adminTests = list) }
        }
    }

    fun adminAddStudent(name: String, mobile: String, pass: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminAddStudent(name, mobile, pass)
            loadAdminData()
        }
    }

    fun adminUpdateStudent(id: String, name: String, mobile: String, pass: String, isActive: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminUpdateStudent(id, name, mobile, pass, isActive)
            loadAdminData()
        }
    }

    fun adminDeleteStudent(id: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminDeleteStudent(id)
            loadAdminData()
        }
    }

    fun adminResetStudentDeviceLock(id: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminResetStudentDeviceLock(id)
            loadAdminData()
        }
    }

    fun adminCreateTest(title: String, isActive: Boolean, reattemptAllowed: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminCreateTest(title, isActive, reattemptAllowed)
            loadAdminData()
        }
    }

    fun adminUpdateTest(id: String, title: String, isActive: Boolean, reattemptAllowed: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminUpdateTest(id, title, isActive, reattemptAllowed)
            loadAdminData()
        }
    }

    fun adminDeleteTest(id: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminDeleteTest(id)
            loadAdminData()
        }
    }

    fun adminSelectTestForQuestions(test: TestItem) {
        _uiState.value = _uiState.value.copy(adminSelectedTestForQuestions = test)
        loadQuestionsForAdminTest(test.id)
    }

    fun loadQuestionsForAdminTest(testId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val res = repository.getQuestionsForTest(testId)
            _uiState.value = _uiState.value.copy(isLoading = false)
            res.onSuccess { qList ->
                _uiState.value = _uiState.value.copy(adminQuestionsForTest = qList)
            }
        }
    }

    fun adminAddQuestion(testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminAddQuestion(testId, qText, options, correctIndex, marks)
            loadQuestionsForAdminTest(testId)
        }
    }

    fun adminUpdateQuestion(id: String, testId: String, qText: String, options: List<String>, correctIndex: Int, marks: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminUpdateQuestion(id, testId, qText, options, correctIndex, marks)
            loadQuestionsForAdminTest(testId)
        }
    }

    fun adminDeleteQuestion(id: String, testId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            repository.adminDeleteQuestion(id, testId)
            loadQuestionsForAdminTest(testId)
        }
    }

    fun updateSupabaseConfig(url: String, anonKey: String) {
        SupabaseConfig.saveConfig(getApplication(), url, anonKey)
        com.example.data.remote.SupabaseClient.resetClient()
        _uiState.value = _uiState.value.copy(errorMessage = "Supabase API સંયોજન અપડેટ થયું!")
    }
}
